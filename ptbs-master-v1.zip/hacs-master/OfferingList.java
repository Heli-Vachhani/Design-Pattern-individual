import java.util.ArrayList;


class OfferingList extends ArrayList<Offering> {

	OfferingList() {
	}
}