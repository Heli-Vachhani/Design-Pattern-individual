
class UserInfoItem {

	public enum USER_TYPE { Buyer, Seller }
	
	String strUserName;
	USER_TYPE UserType; // 0 : Buyer, 1: Seller
}